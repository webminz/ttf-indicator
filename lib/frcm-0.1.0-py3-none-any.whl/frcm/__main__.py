import sys
from pathlib import Path
from frcm import console_main
from frcm.datamodel.model import WeatherData
from frcm.fireriskmodel.compute import compute


if __name__ == "__main__":
    console_main()
